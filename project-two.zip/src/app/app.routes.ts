import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AddComponent } from './add/add.component';
import { EditComponent } from './edit/edit.component';
import { DeleteComponent } from './delete/delete.component';
import { NotFoundComponent } from './not-found/not-found.component';

export const routes: Routes = [
    {path:'',component:HomeComponent},
    {path:'add',component:AddComponent},
    {path:'edit/:id',component:EditComponent},
    {path:'delete/:id',component:DeleteComponent},
    {path:'**',component:NotFoundComponent}
];
