import { Component, OnInit } from '@angular/core';
import { DataServiceService } from '../AppServices/data-service.service';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule,HttpClientModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent implements OnInit {
  data:any[]=[]
  constructor(private serv:DataServiceService){}
  ngOnInit():void{
    this.getdata()
  }

  getdata()
  {
    this.serv.getdata().subscribe((res:any)=>{
      this.data=res;
      console.log(res)
    },
    err=>{
      console.log("Error Found",err)
    })
  }
}
