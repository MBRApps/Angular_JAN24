import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'uppercasechar',
  standalone: true
})
export class UppercasecharPipe implements PipeTransform {

  transform(value: string): string {
    var result=value.toUpperCase();
    return result;
  }

}
