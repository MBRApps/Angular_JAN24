import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { UppercasecharPipe } from '../uppercasechar.pipe';


@Component({
  selector: 'app-custompipes',
  standalone: true,
  imports: [CommonModule,UppercasecharPipe],
  templateUrl: './custompipes.component.html',
  styleUrl: './custompipes.component.css'
})
export class CustompipesComponent {
  msg="i am From INDIA"
}
