import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateDrivenFromsComponent } from './template-driven-froms.component';

describe('TemplateDrivenFromsComponent', () => {
  let component: TemplateDrivenFromsComponent;
  let fixture: ComponentFixture<TemplateDrivenFromsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TemplateDrivenFromsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(TemplateDrivenFromsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
