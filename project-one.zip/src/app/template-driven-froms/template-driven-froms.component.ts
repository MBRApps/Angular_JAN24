import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-template-driven-froms',
  standalone: true,
  imports: [CommonModule,FormsModule],
  templateUrl: './template-driven-froms.component.html',
  styleUrl: './template-driven-froms.component.css'
})
export class TemplateDrivenFromsComponent {
  signup(data:any)
  {
    console.log(data.value)
    data.resetForm()
  }
}
