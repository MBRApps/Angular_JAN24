import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { HighlighterDirective } from '../highlighter.directive';
import { RepeaterDirective } from '../repeater.directive';
import { Repeater1Directive } from '../repeater1.directive';

@Component({
  selector: 'app-cutsomdirectives',
  standalone: true,
  imports: [CommonModule,HighlighterDirective,RepeaterDirective,Repeater1Directive],
  templateUrl: './cutsomdirectives.component.html',
  styleUrl: './cutsomdirectives.component.css'
})
export class CutsomdirectivesComponent {

}
