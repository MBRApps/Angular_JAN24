import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CutsomdirectivesComponent } from './cutsomdirectives.component';

describe('CutsomdirectivesComponent', () => {
  let component: CutsomdirectivesComponent;
  let fixture: ComponentFixture<CutsomdirectivesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CutsomdirectivesComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CutsomdirectivesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
