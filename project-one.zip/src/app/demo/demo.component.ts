import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-demo',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './demo.component.html',
  styleUrl: './demo.component.css'
})
export class DemoComponent {
  i:number=10;
  msg:String="Good Afternoon!";
  id="btnSample";
  phText="Enter Name Here"
  
  isLoggedInn=false;
  className=this.isLoggedInn?'green-text':'red-text'

  mycolor='Orange';

  mystyles={
    color:'Red',
    backgroundColor:'#aabbcc',
    fontSize:'36px'
  }

  

  greetUser():void
  {
     alert('Hi User, Good Afternoon!')
  }
  
  userId="Guest"
  changeUserId()
  {
    this.userId="Admin"
  }
  
}
