import { UppercasecharPipe } from './uppercasechar.pipe';

describe('UppercasecharPipe', () => {
  it('create an instance', () => {
    const pipe = new UppercasecharPipe();
    expect(pipe).toBeTruthy();
  });
});
