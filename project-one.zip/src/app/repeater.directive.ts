import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[appRepeater]',
  standalone: true
})
export class RepeaterDirective {

  constructor(private templateref:TemplateRef<any>,
    private viewcontainer:ViewContainerRef) { }

  @Input('appRepeater') set loop(num:number)
  {
    for(var i=0;i<num;i++)
    {
      this.viewcontainer.createEmbeddedView(this.templateref)
    }
  }
}
