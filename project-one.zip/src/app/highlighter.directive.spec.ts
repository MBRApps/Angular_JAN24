import { HighlighterDirective } from './highlighter.directive';

describe('HighlighterDirective', () => {
  it('should create an instance', () => {
    const directive = new HighlighterDirective();
    expect(directive).toBeTruthy();
  });
});
