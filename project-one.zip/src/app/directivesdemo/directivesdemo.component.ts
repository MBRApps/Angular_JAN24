import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-directivesdemo',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './directivesdemo.component.html',
  styleUrl: './directivesdemo.component.css'
})
export class DirectivesdemoComponent {
  isLoggedinn=false
  products=[
    {id:1,name:'DELL 3526',price:55000,category:101},
    {id:2,name:'DELL 258G',price:42500,category:101},
    {id:3,name:'DELL 1020',price:30000,category:102},
    {id:4,name:'DELL 15P9',price:28500,category:102},
    {id:5,name:'DELL 65GH',price:69000,category:101}
  ]
}
