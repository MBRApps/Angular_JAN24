import { Repeater1Directive } from './repeater1.directive';

describe('Repeater1Directive', () => {
  it('should create an instance', () => {
    const directive = new Repeater1Directive();
    expect(directive).toBeTruthy();
  });
});
