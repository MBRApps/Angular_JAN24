import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-pipesdemo',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './pipesdemo.component.html',
  styleUrl: './pipesdemo.component.css'
})
export class PipesdemoComponent {
  msg="Hello User! I am From INDIA"
  product={id:1,name:'IPhone 15',price:95000}
  amount=56500
  val=15.2369
  val1=60

  dt=new Date()
}
