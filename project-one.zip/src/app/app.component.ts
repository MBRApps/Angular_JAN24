import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { DemoComponent } from './demo/demo.component';
import { SampleComponent } from './sample/sample.component';
import { PipesdemoComponent } from './pipesdemo/pipesdemo.component';
import { DirectivesdemoComponent } from './directivesdemo/directivesdemo.component';
import { TemplateDrivenFromsComponent } from './template-driven-froms/template-driven-froms.component';
import { ReactiveFormsComponent } from './reactive-forms/reactive-forms.component';
import { ProductComponent } from './product/product.component';
import { LifecyclehooksComponent } from './lifecyclehooks/lifecyclehooks.component';
import { Lifecyclehooks1Component } from './lifecyclehooks1/lifecyclehooks1.component';
import { CustompipesComponent } from './custompipes/custompipes.component';
import { CutsomdirectivesComponent } from './cutsomdirectives/cutsomdirectives.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet,DemoComponent,SampleComponent,PipesdemoComponent,DirectivesdemoComponent,
  TemplateDrivenFromsComponent,ReactiveFormsComponent,
ProductComponent,LifecyclehooksComponent,Lifecyclehooks1Component,
CustompipesComponent,CutsomdirectivesComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'project-one'; 
  productlist=[
    {id:1,title:'Product-1',barcode:'PRFG0001'},
    {id:2,title:'Product-2',barcode:'PRFG0002'},
    {id:3,title:'Product-3',barcode:'PRFG0003'},
    {id:4,title:'Product-4',barcode:'PRFG0004'},
    {id:5,title:'Product-5',barcode:'PRFG0005'}
   ] 

   dt=new Date()

   changeDate()
   {
    this.dt=new Date()
   }
}
