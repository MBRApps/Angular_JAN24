import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[appRepeater1]',
  standalone: true
})
export class Repeater1Directive {

  constructor(private templateref:TemplateRef<any>,
    private viewcontainer:ViewContainerRef) { }

    @Input('appRepeater1') set appRepeater1(index:any)
    {
      var ind=parseInt(index)
      this.viewcontainer.clear()
       for(let i=0;i<ind;i++)
       {
        this.viewcontainer.createEmbeddedView(this.templateref,{index:i+1})
       }
      }

}
