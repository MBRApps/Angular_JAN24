import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appHighlighter]',
  standalone: true
})
export class HighlighterDirective {

  constructor(private elementref:ElementRef) {
    // let el=elementref.nativeElement
    // el.style.color='red'
    // el.style.backgroundColor='yellow'
   }

   @HostListener('mouseenter') onMouseEnter()
   {
      this.applycolor('red')
   }

   @HostListener('mouseleave') onMouseLeave()
   {
      this.applycolor('')
   }

   private applycolor(color:string)
   {
     this.elementref.nativeElement.style.color=color
   }
  
}
