import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-sample',
  standalone: true,
  imports: [FormsModule],
  // templateUrl: './sample.component.html',
  template:`<h1>Hello User</h1>`,
  styleUrl: './sample.component.css'
})
export class SampleComponent 
{
  name:String="n/a"; 
  logData(userid:any,password:any)
  {
    console.log({UserId:userid.value,Password:password.value})
  }

  counter:number=0
  increment()
  {
    this.counter=this.counter+1
  }
  decrement()
  {
    this.counter=this.counter-1
  }

  data:String=""
  showMsg()
  {
    alert(this.data)
  }

 
  result:String=""
  change2Upper(inp:any)
  {
    this.result=inp.value.toUpperCase()
  }

}
