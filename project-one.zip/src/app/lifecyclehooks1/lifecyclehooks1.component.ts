import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-lifecyclehooks1',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './lifecyclehooks1.component.html',
  styleUrl: './lifecyclehooks1.component.css'
})
export class Lifecyclehooks1Component {
  ngOnInit():void{
    console.log('-----------ngOnInit is Invoked------------------')
  }
}
