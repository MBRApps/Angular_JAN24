import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Lifecyclehooks1Component } from './lifecyclehooks1.component';

describe('Lifecyclehooks1Component', () => {
  let component: Lifecyclehooks1Component;
  let fixture: ComponentFixture<Lifecyclehooks1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Lifecyclehooks1Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(Lifecyclehooks1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
