import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-lifecyclehooks',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './lifecyclehooks.component.html',
  styleUrl: './lifecyclehooks.component.css'
})
export class LifecyclehooksComponent {
  @Input() today:any;
  constructor()
  {
    console.log("----Constructor Invoked----")
  }
  ngOnChanges()
  {
    console.log("----ngOnChanges Invoked----")
  }
}
