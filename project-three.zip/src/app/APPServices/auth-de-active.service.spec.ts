import { TestBed } from '@angular/core/testing';

import { AuthDeActiveService } from './auth-de-active.service';

describe('AuthDeActiveService', () => {
  let service: AuthDeActiveService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AuthDeActiveService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
