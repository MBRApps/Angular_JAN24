import { TestBed } from '@angular/core/testing';

import { AuthServiceResolverService } from './auth-service-resolver.service';

describe('AuthServiceResolverService', () => {
  let service: AuthServiceResolverService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AuthServiceResolverService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
