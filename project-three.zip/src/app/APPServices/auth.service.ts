import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService implements CanActivate {

  constructor(private router:Router) { }

  canActivate(): boolean  {
    const IsLoggedInn=true
    if(IsLoggedInn)
      return true;
    else
      return false;
  }
}




