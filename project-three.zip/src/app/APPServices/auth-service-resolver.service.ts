import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthServiceResolverService implements Resolve<any[]> {

  constructor() { }
  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): any[] {
    return [
      {id:1,title:'C'},
      {id:2,title:'C++'},
      {id:3,title:'SQL'},
      {id:4,title:'Angular'}
    ]
  }
}
