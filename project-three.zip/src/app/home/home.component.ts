import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {
  courses:any

  constructor(private route:ActivatedRoute)
  {
    this.courses=route.snapshot.data['courselist']
  }
}
