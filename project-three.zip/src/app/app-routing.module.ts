import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ServicesComponent } from './services/services.component';
import { ContactComponent } from './contact/contact.component';
import { AuthService } from './APPServices/auth.service';
import { AuthDeActiveService } from './APPServices/auth-de-active.service';
import { AuthServiceResolverService } from './APPServices/auth-service-resolver.service';

const routes: Routes = [
  {path:'',component:HomeComponent,
resolve:{courselist:AuthServiceResolverService}},
  {path:'about',component:AboutComponent},
  {path:'services',component:ServicesComponent,
  canActivate:[AuthService]},
  {path:'contact',component:ContactComponent,
canDeactivate:[AuthDeActiveService]},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
