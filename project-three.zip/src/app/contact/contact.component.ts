import { Component, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrl: './contact.component.css'
})
export class ContactComponent {

  @ViewChild('contactform')
  public contactdetailsform!:NgForm
  
  contact(data:any)
  {
    console.log(data)
  }
}
