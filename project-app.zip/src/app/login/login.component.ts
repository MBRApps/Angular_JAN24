import { Component } from '@angular/core';
import { Router } from '@angular/router';
import axios from 'axios';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  constructor(private router:Router){}
  usersdata:any[]=[]
  login(data:any)
  {
     axios.get('http://localhost:3000/users').then
     (res=>{
        this.usersdata=res.data
     })

     
        if(this.usersdata.length>0)
        {
          console.log('ok')
          for(const user of this.usersdata)
          {
            console.log(user)
              if(user.userid==data.username && user.password==data.password)
              {
                  if(user.role==1)
                  {
                    this.router.navigate(['/admin'])
                  }
                  else{
                    this.router.navigate(['/user'])
                  }
              }
             
          }
        }
  }
}
