import { Component, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent implements OnInit {

  userdata:any[]=[]

  constructor(private serv:DataService){}
  ngOnInit(): void {
    this.getdata()
  }
  getdata()
  {
    this.serv.getdata().subscribe((res:any)=>{
      this.userdata=res.data
      console.log(res.data)
    },error=>{
      console.log(error)
    })
  }

}
