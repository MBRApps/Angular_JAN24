import { Component, OnInit } from '@angular/core';
import axios from 'axios';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent implements OnInit {

  userdata:any[]=[]

  ngOnInit(): void {
    axios.get('https://reqres.in/api/users?page=2')
    .then(res=>{
      console.log(res.data.data)
      this.userdata=res.data.data
    })
    .catch(err=>{
      console.log(err)
    })
  }

}
